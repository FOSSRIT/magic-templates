==================
Welcome to Scratch
==================

.. image:: images/masthead.png

===============
Badge Collector
===============
In this tutorial, you will learn:

* The basics of the scratch interface
* Loading Sprites
* Building basic block scripts
* Keeping score (Variables)
* Sounds

.. image:: images/game_screenshot.gif

The Scratch Interface
---------------------
.. image:: images/scratch_welcome.png

.. image:: images/scratch_size.jpg

Creating the Sprite
-------------------
Lets start with a clean state by deleting the default sprite by
right-clicking on the sprite and selecting delete.

.. image:: images/delete_sprite.jpg

Now that our stage is empty, we need to add a new sprite from file.

.. image:: images/new_sprite.jpg

We will start off by picking one of our badges. After clicking the new
sprite from file button, a file browser will appear.  You will be able
to find the badges in a folder called "Files" along side the this
tutorial.  Example, if the tutorial is located 
"D:/1_Badge_Collector/Tutorial/" then the images can be found in
"D:/1_Badge_Collector/Files/" The badges can be found within a folder
called "Badges".

.. image:: images/select_badge.jpg

You will want to prevent the badge from rotating as it moves by
selecting the "don't rotate" button.  While you are here, you may name
your sprite if desired.  Naming your sprites now will help you out later
on.

.. image:: images/dont_rotate.jpg

Making the Sprite Move
----------------------
Now lets make your new sprite move when the green flag is selected.

Scratch uses blocks to control sprites in the game.  The blocks are 
categorized into eight categories.  These categories are color coded
for simplicity as all blocks are colored to match their category.

* Motion: Blocks that deal with movement of the sprite.
* Control: Blocks that control when and how things interact.
* Looks: Blocks that change the appearance of the sprite.
* Sensing: Blocks that can be used with control blocks to detect other
  sprites or retrieve information from the player.
* Sound: Blocks that control sounds.
* Operators: Blocks that can be used to do calculations like multiply and
  divide.
* Pen: Blocks that control the pen status of a sprite.  Sprites have the
  ability to draw their path.
* Variables: Blocks that be used to store and retrieve variables.

From the control category, drag the "When Green Flag clicked" to the
script panel of the sprite.

.. image:: images/code_001.jpg

Next we want to make a simple loop.  Drag the forever block to the
previous block.  Inside the forever block, lets place a "move 10 steps"
and an "if on edge, bounce" block from the motion category.  Lets slow
down the sprite by changing the 10 in the move block to 5.

.. image:: images/code_002.jpg

You may test your code by clicking the green flag in the corner of
the screen.  You may also test individual blocks by clicking on the
block, the program will flow from that point.  Press the stop sign to
stop the game.

Bouncing back and forth is interesting, but lets make it pick a random
direction each time the game starts by turning to a random direction.
Drag one of the "turn 15 degrees" between the "when green flag clicked"
and the forever block.

To make it random, drag the "pick random 1 to 10" block from the
operators category into the turn block.  Change the 10 to 360.  You
should see that blocks like operators can usually be changed.  You can
drag other blocks into spaces that can take input if they have the same
shape.  In this example the oval input can take an oval block and a
diamond input can take a diamond block (diamond blocks are yes-no
responses and oval blocks are usually numbers).

.. image:: images/code_003.jpg

Now your sprite will move in a random direction every time the game has
started.

Adding a Score
--------------
Now we will add a score counter to the game.  First we need to add a
variable to store the score.  Click "Make a variable" in the variables
category.  Name the variable "Score" and make it accessible for all
sprites.

.. image:: images/code_004.jpg

Now that we have a place to store the score, lets add click element
to the sprite.  Drag "when Sprite1 clicked" to the scripts panel.  Next
drag the "change Score by 1" from the variables category to the block
you just placed.  Feel free to modify the amount the score is changed by.

.. image:: images/code_005.jpg

One more thing we need to do before we are done with the score, reset it
when the game starts.  Select the "Stage" from the sprite selector.  The
stage is for global scripts.

Add a "when green flag clicked" block and a "set Score to 0" block to
the stage's script panel.

.. image:: images/code_006.jpg

The Little Extras
-----------------
To make the game a bit more interesting, let the sprite change direction
and pick a random position when you get a point.

.. image:: images/code_007.jpg

Lets add a bit more feedback for the player by adding sound when the
badge has been clicked.  Click on the sound tab and import a sound for
the click noise.

.. image:: images/new_sound.jpg

Now just add the sound to the click script by switching back to the
scripts tab and drag the "play sound" block from the sound category
over to bottom of the when Sprite1 clicked.

.. image:: images/code_008.jpg

Duplicating Sprites
-------------------
Lets add some more badges to the game by right clicking on the badge
sprite and click duplicate.

Sprites use costumes to manage their appearance.  This allows a single
sprite to have multiple images that can be chosen by look blocks.
Animations are possible with multiple costumes.  This tutorial will only
be using one costume at a time so feel free to change the sprite image
by clicking the "costumes" tab and "import"a new costume.  After you have
picked the new costume, click the x on the old costume to remove it.

Add two or three more badges using this duplicate and change costume
method.

.. image:: images/duplicated.jpg

Adding an enemy
---------------
Now to make the game more interesting, we need to add a way to lose.

Duplicate one of the sprites and change the icon to something unique
like a skull.

Go to the Scripts tab and remove everything under the when sprite
clicked block by dragging the block back to the block selector panel or
right clicking on the block and select delete.

The sprite should say Game Over for a couple seconds and then stop the
game.

.. image:: images/code_009.jpg

Feel free to duplicate the enemy as many times as you would like.

Adding Background Images and Sounds
-----------------------------------
Adding a background image is just like changing the picture of a sprite.
Open the stage from the sprite selection box and click the Background
tab.

Adding background music by importing music in the sound tab of the Stage.
Once you have imported the sound, add a forever loop and play sound
until done block to the end of the "when green flag clicked" code block.

.. image:: images/code_010.jpg
