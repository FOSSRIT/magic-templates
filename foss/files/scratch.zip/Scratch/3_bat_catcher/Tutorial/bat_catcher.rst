================
Your Third Game
================

.. image:: images/masthead.png

===========
Bat Catcher
===========
In this tutorial, you will learn:

* Creation of custom sprites
* Pratice making games on your own with minimum instruction

.. image:: images/game_screenshot.gif

.. image:: images/gameplay.gif

=============
Custom Images
=============
Lets create a few custom images by clicking the new sprite button.

.. image:: images/new_sprite.jpg

This will bring up a paint interface that will allow you to create
your own sprite.  For this game you will want to make your own fog.
You will also make a tongue sprite, and an eye sprite.

After creating the fog, place it by the bottom of the screen.  Next
drag the eye sprites and the tongue to the fog.

If the sprites are not in the order you would like, you can use
look blocks to move the sprites between layers (bring to front, go 
back x layers).

The final sprite you will want is the bat, use the one from the stock
images included in scratch or you may make your own.

=========
Scripting
=========
You will want the bat to randomly move around the screen and when it
touches the tongue to jump randomly and give a point to the score.

.. image:: images/bat.gif

The eyes you will want to always face the bat.

.. image:: images/eye.gif

The tongue should hide when the green flag is pressed.  When the user
presses the spacebar, the tongue point towards the bat and then show
for .2 seconds and then hide.

.. image:: images/tongue.gif


