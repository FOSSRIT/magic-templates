================
Your Second Game
================

.. image:: images/masthead.png

=============
River Paddler
=============
In this tutorial, you will learn:

* Reacting to key presses
* Basic Animation and movement
* Detecting Collisions
* Broadcasting Messages between sprites

.. image:: images/game_screenshot.gif

Using Costumes
==============
In scratch, animations are done by changing the costume.  Lets start
off by deleting the default sprite and creating a new one with the canoe
image.

Lets load in a few more images for the sprite by importing canoe left
and canoe right.gif.  You will notice that each gif file has been
expanded to multiple costumes.

.. image:: images/code_001.jpg

At this point you should have your canoe sprite with multiple costumes.
Soon We will animate the canoe by quickly switching between the costumes
you just imported.

The canoe orientation will be facing to the left, you may want to rotate
it so that it is facing up.  To rotate the sprite, right click on the
sprite in the stage and click rotate.  Drag the sprite in the up
position.  This could also be done by the point in direction block when
the game starts.

Now lets start animating.  When the right arrow is pressed, we should
quickly switch between all the left costumes.

In the Scripts tab for the canoe

* When right arrow is pressed
* Switch to the left costume,
* Loop four times changing to the next costume, delaying .01 seconds
  each loop (change a "wait 1 secs" block to .01 after dragging the block)
* Finally switch back to the canoe costume

Repeat for the left arrow with the right costume.

.. image:: images/code_002.jpg

Adding Basic movement
=====================
Now that we are animating when keys are pressed, lets move our canoe.

Add a "change x by -2" and an "if on edge, bounce" inside the repeat
block to the left arrow key press script.  Do the same with the right
arrow except change by positive 2.

.. image:: images/code_003.jpg

Adding obstacles
================
Lets add in some obstacles to crash into.  Create a new sprite with an
image of your choice.

In the sprite's script panel, we want to have the obstacle move down when
the left or right arrow is pressed.  Like before, we should put it in a
loop that repeats 4 times moving the obstacle each time so it looks like
it is moving with the canoe animation.

We would also like to have the obstacle move down the river on its own
and reset to the top of the river in a random x position when it goes
out of sight.

See if you can figure this out on your own.  When the game starts
we should enter into a forever loop, checking the y position to see if
it is less then -170.  If so we should set our x randomly between -225
and 225 and set our y back to 170.  During this loop we should also
move our obstacle down the screen by changing it's y by a negative value.
Adding a wait block can be used to slow this loop down.

See what you can come up with, one way of doing this could look
something like this:

.. image:: images/code_004.jpg

Detecting collisions
====================
When we hit the obstacle, we should end the game.  As there can be many
obstacles and only one Canoe, we should have our obstacle check if it
is hitting the canoe.  In our forever loop in the obstacle, can add an
if block to check if we are touching the canoe (if you didn't name your
sprite, it would be sprite 1).

When we hit the canoe, the object should say Crash and tell the canoe
to disappear and end the game.  In scratch, sprites communicate using
the broadcast block.  Drag a broadcast block from control into the if
block you just put down and create a new message by clicking the message
and click add.  Name the new message Game over.

You obstacle should look something like this:

.. image:: images/code_005.jpg

Now that we are sending a game over message, we need to have our canoe
listen for it.  On the canoe sprite, drag the block "when I receive Game
Over" to the scripts panel.  Under it drag a hide, wait 3 seconds, and a
stop all block to end the game.  Now when the game ends, the canoe will
stop.

Because we are hiding our canoe when it crashes, we need to show it when
the game starts.  Add a show block to a when green flag clicked block.

.. image:: images/code_006.jpg

Feel free to duplicate the obstacle block a few times to make the game
a bit more interesting.  Moving them to different places on the screen
as well as changing the image of the sprites may help.

If you are feeling adventurous, you can make the sprites have different
costumes that change randomly every time it moves to the top.  Otherwise
feel free to just change the images of the sprites as we have done in
the previous tutorial.

Add a score
===========
Using the same method in the previous tutorial, add a score variable
that is set to zero at the start of the game by the stage.  Duplicate
an obstacle sprite, but when you touch it, add to your score and move
it back to the top.  When it falls off the screen and is moved by the
y position check, subtract from the score.

.. image:: images/code_007.jpg

Experiment
==========
If you have time, feel free to experiment.  One idea, add a crocodile
that slowly moves towards the canoe instead of just floating down the
river.  Hint: instead of changing the y position at the end of the
forever loop, point it towards the canoe and move 1 step.

Final Touches
=============
Add a background to the stage, possibly some music, and adjust movement
speeds as desired.
